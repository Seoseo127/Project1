package com.movie.management;

import java.util.List;

public class SeatTEST {
    public static void main(String[] args) {
        SeatDAO seatDAO = new SeatDAO();

        // 1. 좌석 추가 (Insert 테스트)
        SeatVO newSeat = new SeatVO(0, "A", 2, "N"); // seatId는 0으로 넘기면 자동 생성
        boolean insertResult = seatDAO.insertSeat(newSeat);
        System.out.println("좌석 추가 결과: " + (insertResult ? "성공" : "실패"));

        // 2. 전체 좌석 조회 (Select 테스트)
        List<SeatVO> seatList = seatDAO.getAllSeats();
        System.out.println("=== 좌석 목록 ===");
        for (SeatVO seat : seatList) {
            System.out.printf("ID: %d, Row: %s, Col: %d, Reserved: %s\n",
                    seat.getSeatId(), seat.getSeatRow(), seat.getSeatCol(), seat.getReserved());
        }
    }
}
