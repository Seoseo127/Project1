package com.movie.management;

import java.sql.Date;

public class UserMovieTest {


	    public static void main(String[] args) {
	        // 테스트용 영화 객체 생성
	        MovieVO movie1 = new MovieVO(1, "주토피아", "애니메이션", Date.valueOf("2025-04-10"), 108);
	        MovieVO movie2 = new MovieVO(2, "짱구는못말려", "애니메이션", Date.valueOf("2025-04-11"), 111);
	        
	        

	        // UserMovie 객체 생성
	        UserMovie userMovie = new UserMovie();

	        // 1. 영화 등록 테스트
	        if (userMovie.insert(movie1)) {
	            System.out.println("영화 등록 성공");
	        } else {
	            System.out.println("영화 등록 실패");
	        }
	        
	        if (userMovie.insert(movie2)) {
	            System.out.println("영화 등록 성공");
	        } else {
	            System.out.println("영화 등록 실패");
	        }
	        
//	        if (userMovie.insert(movie3)) {
//	            System.out.println("영화 등록 성공");
//	        } else {
//	            System.out.println("영화 등록 실패");
//	        }

	        // 2. 영화 수정 테스트
	        movie1.setTitle("주토피아");
	        movie1.setRuntime(138);
	        if (userMovie.update(movie1)) {
	            System.out.println("영화 수정 성공");
	        } else {
	            System.out.println("영화 수정 실패");
	        }
	        
	        movie2.setTitle("짱구는 못말려");
	        movie2.setRuntime(100);
	        if (userMovie.update(movie2)) {
	            System.out.println("영화 수정 성공");
	        } else {
	            System.out.println("영화 수정 실패");
	        }

//	        movie3.setTitle("213");
//	        movie3.setRuntime(899);
//	        if (userMovie.update(movie3)) {
//	            System.out.println("영화 수정 성공");
//	        } else {
//	            System.out.println("영화 수정 실패");
//	        }
	        
	        
	        // 3. 영화 삭제 테스트
	        if (userMovie.delete(movie1.getMovieId())) {
	            System.out.println("영화 삭제 성공");
	         } else {
	            System.out.println("영화 삭제 실패");
	        }
	    }
	}

