package com.movie.management;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SeatDAO {
    private static final String URL = "jdbc:oracle:thin:@192.168.18.12:1521:xe";
    private static final String USER = "MOVIE";
    private static final String PASSWORD = "movie";

    // 데이터베이스 연결
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // 좌석 추가 (Insert) - 시퀀스 없이 수동으로 seat_id 지정
    public boolean insertSeat(SeatVO seatVO) {
        String sql = "INSERT INTO seat (seat_id, seat_row, seat_col, reserved) " +
                     "VALUES (?, ?, ?, ?)";  // seat_id를 수동으로 설정

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // 값 설정
            ps.setInt(1, seatVO.getSeatId());  // seat_id는 VO에서 받아온 값
            ps.setString(2, seatVO.getSeatRow());
            ps.setInt(3, seatVO.getSeatCol());
            ps.setString(4, seatVO.getReserved());

            // 실행
            int result = ps.executeUpdate();
            return result > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 모든 좌석 조회 (Select)
    public List<SeatVO> getAllSeats() {
        List<SeatVO> seatList = new ArrayList<>();
        String sql = "SELECT seat_id, seat_row, seat_col, reserved FROM seat";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                seatList.add(new SeatVO(
                        rs.getInt("seat_id"),
                        rs.getString("seat_row"),
                        rs.getInt("seat_col"),
                        rs.getString("reserved")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return seatList;
    }
}

