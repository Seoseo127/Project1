package com.movie.management;

public class SeatVO {
    private int seatId;     // 좌석 고유 ID
    private String seatRow; // 좌석 행 (A, B, C 등)
    private int seatCol;    // 좌석 열 (1, 2, 3 등)
    private String reserved; // 예약 여부 ('Y' 또는 'N')

    // 생성자
    public SeatVO(int seatId, String seatRow, int seatCol, String reserved) {
        this.seatId = seatId;
        this.seatRow = seatRow;
        this.seatCol = seatCol;
        this.reserved = reserved;
    }

    // Getter와 Setter
    public int getSeatId() {
        return seatId;
    }

    public void setSeatId(int seatId) {
        this.seatId = seatId;
    }

    public String getSeatRow() {
        return seatRow;
    }

    public void setSeatRow(String seatRow) {
        this.seatRow = seatRow;
    }

    public int getSeatCol() {
        return seatCol;
    }

    public void setSeatCol(int seatCol) {
        this.seatCol = seatCol;
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved;
    }

    // 좌석 정보 출력 (optional)
    @Override
    public String toString() {
        return "SeatVO [seatId=" + seatId + ", seatRow=" + seatRow + ", seatCol=" + seatCol + ", reserved=" + reserved + "]";
    }
}

