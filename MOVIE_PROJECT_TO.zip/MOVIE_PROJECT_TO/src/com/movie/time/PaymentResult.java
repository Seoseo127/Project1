package com.movie.time;

import java.sql.*;
import java.util.Scanner;

public class PaymentResult {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 예약 ID를 문자열로 입력받기
        System.out.print("예약 ID를 입력하세요: ");
        String reservationIdInput = scanner.nextLine();  // 문자열로 입력 받기

        // 예약 ID가 비어있는지 확인
        if (reservationIdInput.trim().isEmpty()) {
            System.out.println("예약 ID는 비워둘 수 없습니다.");
            return;
        }

        // 예약 ID에 대한 결제 상태 확인
        checkBookingStatus(reservationIdInput);
    }

    private static void checkBookingStatus(String reservationId) {
        String url = "jdbc:oracle:thin:@192.168.18.12:1521:xe";  // DB 연결 URL
        String username = "MOVIE";  // DB 사용자명
        String password = "movie";  // DB 비밀번호

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(url, username, password);

            // 예약 ID에 해당하는 예약 정보 조회
            String sql = "SELECT reserved, payment_status FROM RESERVATION WHERE reservation_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, reservationId);  // 예약 ID를 문자열로 입력

            rs = pstmt.executeQuery();

            // 예약이 존재하는지 확인
            if (rs.next()) {
                // 결제 상태 조회
                String reserved = rs.getString("reserved");
                String paymentStatus = rs.getString("payment_status");

                // 예약된 상태 확인
                if (reserved != null && reserved.equals("1")) {
                    if (paymentStatus == null) {
                        System.out.println("결제 상태: 결제 정보가 없습니다.");
                    } else {
                        System.out.println("결제 상태: " + paymentStatus);
                    }
                } else {
                    System.out.println("예약이 완료되지 않았습니다.");
                }
            } else {
                System.out.println("해당 예약 ID를 찾을 수 없습니다.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
