package com.movie.payment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    private static final String URL = "jdbc:oracle:thin:@192.168.18.12:1521:xe";
    private static final String USER = "MOVIE";
    private static final String PASSWORD = "movie";

    // 데이터베이스 연결
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // 결제 정보 조회 (payment_id로 조회)
    public PaymentVO getPaymentInfo(int paymentId) {
        String sql = "SELECT p.payment_id, p.movie_name, s.seat_row, s.seat_col, p.show_time, p.payment_status "
                   + "FROM payment p "
                   + "JOIN seat s ON p.payment_id = s.seat_id " // 수정된 부분
                   + "WHERE p.payment_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, paymentId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new PaymentVO(
                        rs.getInt("payment_id"),
                        rs.getString("movie_name"),
                        rs.getString("seat_row") + " " + rs.getInt("seat_col"), // 좌석 정보를 조합
                        rs.getString("show_time"),
                        rs.getString("payment_status")
                    );
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;  // 결제 정보가 없을 경우 null 반환
    }
}