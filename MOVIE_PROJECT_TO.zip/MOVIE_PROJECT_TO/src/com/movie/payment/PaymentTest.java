package com.movie.payment;

public class PaymentTest {
    public static void main(String[] args) {
        PaymentDAO paymentDAO = new PaymentDAO();
        int paymentId = 1;  // 예시로 payment_id 1번을 조회한다고 가정

        // 결제 정보 조회
        PaymentVO payment = paymentDAO.getPaymentInfo(paymentId);
        if (payment != null) {
            System.out.println(payment);
        } else {
            System.out.println("결제 정보를 찾을 수 없습니다.");
        }
    }
}