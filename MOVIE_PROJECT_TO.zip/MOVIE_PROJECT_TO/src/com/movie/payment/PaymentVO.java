package com.movie.payment;

public class PaymentVO {
    private int paymentId;    // 결제 고유 ID
    private String movieName; // 예매한 영화명
    private String seatInfo;  // 예매한 좌석 (행, 열)
    private String showTime;  // 상영 시간
    private String paymentStatus; // 결제 상태 ('성공', '실패')

    // 생성자
    public PaymentVO(int paymentId, String movieName, String seatInfo, String showTime, String paymentStatus) {
        this.paymentId = paymentId;
        this.movieName = movieName;
        this.seatInfo = seatInfo;
        this.showTime = showTime;
        this.paymentStatus = paymentStatus;
    }

    // Getter와 Setter
    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getSeatInfo() {
        return seatInfo;
    }

    public void setSeatInfo(String seatInfo) {
        this.seatInfo = seatInfo;
    }

    public String getShowTime() {
        return showTime;
    }

    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    @Override
    public String toString() {
        return "PaymentVO [paymentId=" + paymentId + ", movieName=" + movieName + ", seatInfo=" + seatInfo + 
               ", showTime=" + showTime + ", paymentStatus=" + paymentStatus + "]";
    }
}