package com.movie.id;

import java.sql.*;
import java.util.Scanner;

public class Memberid {
    private static final Scanner scanner = new Scanner(System.in);
    private static final String URL = "jdbc:oracle:thin:@192.168.18.12:1521:xe";
    private static final String USER = "MOVIE";
    private static final String PASSWORD = "movie";

    // DB 연결
    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // 회원 아이디 유효성 검사
    private static boolean isValidUserId(String userId) {
        String sql = "SELECT 1 FROM \"USERS\" WHERE \"USER_ID\" = ?";

        try (
            Connection conn = getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)
        ) {
            ps.setString(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // 결과가 있으면 true
            }
        } catch (SQLException e) {
            System.err.println("DB 오류: " + e.getMessage());
        }
        return false;
    }

    // 회원 아이디 입력
    public static String inputMemberId() {
        while (true) {
            System.out.print("회원 아이디를 입력하세요: ");
            String userId = scanner.nextLine();
            if (isValidUserId(userId)) {
                return userId;
            }
            System.out.println("등록된 아이디가 아닙니다. 다시 입력하세요.");
        }
    }

    public static void main(String[] args) {
        String userId = inputMemberId();
        System.out.println("등록된 아이디입니다.: " + userId);
    }
}